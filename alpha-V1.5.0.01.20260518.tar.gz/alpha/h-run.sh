#!/usr/bin/env bash
# HiveOS runs this in a screen session - DO NOT create another!
#
# alpha custom miner — thin launcher (rev 1.3.0.1)
#
# HiveOS contract (see hiveos-wrapper-contract): the /hive/miners/custom/
# dispatcher EXECUTES this file as a child, and BEFORE doing so it runs
#     ps aux | grep "<minerdir>/alpha/h-run.sh"
# and refuses to start ("already running", exit 1) if any process still has
# ".../alpha/h-run.sh" in its argv. 1.0.18 is safe only because it
# `exec $MINER_BIN` (persistent argv becomes ".../alpha/alpha …").
#
# So this launcher must NOT remain the long-lived process. It sets up the
# log redirection (same as 1.0.18) and immediately `exec`s a DIFFERENTLY
# NAMED supervisor (alpha-supervise.sh) — the persistent argv then contains
# no "h-run.sh", so restarts are never blocked by the dispatcher guard.

SCRIPT_PATH=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
[[ -f "$SCRIPT_PATH/h-manifest.conf" ]] && source "$SCRIPT_PATH/h-manifest.conf"

LOG="${CUSTOM_LOG_BASENAME:-/var/log/miner/custom/alpha}.log"
mkdir -p "$(dirname "$LOG")" 2>/dev/null

# Route this process's (and the supervisor's + miner's) stdout/stderr to the
# log + screen, exactly like 1.0.18, then hand off to the supervisor.
exec > >(exec tee -a "$LOG") 2>&1

SUP="$SCRIPT_PATH/alpha-supervise.sh"
if [[ ! -f "$SUP" ]]; then
    echo "FATAL: supervisor not found: $SUP"
    exit 1
fi
exec bash "$SUP"
echo "FATAL: failed to exec supervisor: $SUP"
exit 1
