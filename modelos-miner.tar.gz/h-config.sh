#!/usr/bin/env bash
#
# h-config.sh — Translate HiveOS flight-sheet variables into the MODELOS_* env
# vars consumed by the miner binary. It has NO config file; everything is
# driven by environment.
#
# Sourced (not executed) by h-run.sh so the exports propagate.
#
# HiveOS supplies:
#   $CUSTOM_TEMPLATE         "%WAL%.%WORKER_NAME%"  → already expanded to wallet.worker
#   $CUSTOM_URL              "host:port[,host:port,...]"
#   $CUSTOM_USER_CONFIG      Extra "KEY=value" lines from the flight sheet
#   $WORKER_NAME             Rig name
#

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HIVE_CUSTOM_TEMPLATE="${CUSTOM_TEMPLATE:-}"
HIVE_CUSTOM_URL="${CUSTOM_URL:-}"
HIVE_CUSTOM_USER_CONFIG="${CUSTOM_USER_CONFIG:-}"

# shellcheck source=h-manifest.conf disable=SC1091
. "$SCRIPT_DIR/h-manifest.conf"

[[ -n "$HIVE_CUSTOM_TEMPLATE" ]] && CUSTOM_TEMPLATE="$HIVE_CUSTOM_TEMPLATE"
[[ -n "$HIVE_CUSTOM_URL" ]] && CUSTOM_URL="$HIVE_CUSTOM_URL"
[[ -n "$HIVE_CUSTOM_USER_CONFIG" ]] && CUSTOM_USER_CONFIG="$HIVE_CUSTOM_USER_CONFIG"

# --- Wallet + worker ---
# CUSTOM_TEMPLATE comes through as "wallet.worker" (HiveOS already substituted).
template="${CUSTOM_TEMPLATE}"
wallet="${template%%.*}"
worker="${template#*.}"
[[ "$worker" == "$template" ]] && worker="${WORKER_NAME:-default}"

export MODELOS_POOL_WALLET="$wallet"
export MODELOS_POOL_WORKER="$worker"

# --- Pool endpoint: take the first comma-separated entry, strip any scheme ---
pool_url="${CUSTOM_URL%%,*}"
pool_url="${pool_url#stratum+tcp://}"
pool_url="${pool_url#tcp://}"
pool_url="${pool_url#stratum2+tcp://}"
pool_url="${pool_url#grpc://}"
pool_url="${pool_url#grpcs://}"

pool_host="${pool_url%%:*}"
pool_port="${pool_url##*:}"
[[ "$pool_port" == "$pool_url" ]] && pool_port=5566

export MODELOS_POOL_HOST="$pool_host"
export MODELOS_POOL_PORT="$pool_port"

# --- Extra arbitrary MODELOS_* overrides from the flight sheet ---
# Format in HiveOS "Custom miner config" box:
#   MODELOS_GPU_INDICES=0,1
#   MODELOS_MINE_M=8192
#   MODELOS_LOG_LEVEL=Debug
#   MODELOS_POOL_TLS=1
# Lines may be newline- or semicolon-separated.
if [[ -n "${CUSTOM_USER_CONFIG:-}" ]]; then
    while IFS= read -r line; do
        line="${line%%#*}"
        line="$(echo "$line" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
        [[ -z "$line" ]] && continue
        [[ "$line" =~ ^MODELOS_[A-Z0-9_]+= ]] || continue
        # 'line' is in KEY=value form; export accepts that as an assignment.
        # shellcheck disable=SC2163
        export "$line"
    done < <(echo "$CUSTOM_USER_CONFIG" | tr ';' '\n')
fi

# --- TLS compatibility + defaults ---
# MODELOS_POOL_TLS is the current miner env var. MODELOS_POOL_USE_TLS remains
# accepted for older flight sheets and package snippets.
if [[ -z "${MODELOS_POOL_TLS:-}" && -n "${MODELOS_POOL_USE_TLS:-}" ]]; then
    export MODELOS_POOL_TLS="$MODELOS_POOL_USE_TLS"
fi
if [[ -z "${MODELOS_POOL_TLS:-}" ]]; then
    if [[ "${MODELOS_POOL_PORT:-443}" == "443" ]]; then
        export MODELOS_POOL_TLS=1
    else
        export MODELOS_POOL_TLS=0
    fi
fi
export MODELOS_POOL_USE_TLS="$MODELOS_POOL_TLS"

# --- Observability defaults ---
export MODELOS_HIVEOS_STATS_PATH="${MODELOS_HIVEOS_STATS_PATH:-/run/hive/modelos-miner-stats.json}"
export MODELOS_LOG_LEVEL="${MODELOS_LOG_LEVEL:-Information}"
export MODELOS_METRICS_PORT="${MODELOS_METRICS_PORT:-9100}"

# --- Session persistence (identity_key survives restarts → same miner_id) ---
SESSION_DIR="$SCRIPT_DIR/session"
mkdir -p "$SESSION_DIR"
export MODELOS_SESSION_FILE="${MODELOS_SESSION_FILE:-$SESSION_DIR/session.json}"

mkdir -p /var/log/miner/modelos-miner
{
    echo "[$(date -u +%FT%TZ)] h-config:"
    echo "  MODELOS_POOL_HOST=$MODELOS_POOL_HOST"
    echo "  MODELOS_POOL_PORT=$MODELOS_POOL_PORT"
    echo "  MODELOS_POOL_TLS=$MODELOS_POOL_TLS"
    echo "  MODELOS_POOL_WORKER=$MODELOS_POOL_WORKER"
    echo "  MODELOS_SESSION_FILE=$MODELOS_SESSION_FILE"
    echo "  MODELOS_GPU_INDICES=${MODELOS_GPU_INDICES:-all}"
} >> /var/log/miner/modelos-miner/h-config.log
