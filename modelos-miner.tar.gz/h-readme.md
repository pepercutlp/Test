# modelOS Miner for HiveOS

> ⚠️ **EXPERIMENTAL — test with caution.** The HiveOS package has not been fully tested
> on production rigs yet. Try it on a spare/test worker first, watch the dashboard and
> logs, and don't convert a whole farm to it until you've confirmed it mines cleanly on
> your hardware. The Docker miner (`modeloslab/vllm-miner:latest`) is the proven path.

The modelOS miner mines **MDL** (and **PRL** via merge-mining) on the modelOS pool and
reports hashrate, temperature, fan, uptime, and share counts to the HiveOS dashboard.

On HiveOS the miner runs **mining-only** on bare metal (no AI inference — that path needs
the Docker image). Every GPU on the rig mines.

## Flight Sheet

- **Miner:** Custom
- **Coin:** Custom (`pearl`)
- **Wallet:** your **MDL** address (`mdl1...`)
- **Pool:** `stratum.modeloslab.xyz:5566`
- **Template:** `%WAL%.%WORKER_NAME%`

The pool endpoint is **plain TCP** — the package defaults to **TLS off** on port 5566.
Do not enable TLS for the public modelOS pool.

## Earn PRL too (merge-mining)

The flight-sheet wallet is your MDL address. To also earn Pearl from the same work, add
your PRL payout address in the **Custom miner config** box:

```text
MODELOS_POOL_PEARL_WALLET=prl1youraddress
```

## Custom Miner Config

Use the HiveOS "Custom miner config" box for optional `MODELOS_*` overrides — one per
line, or separated by semicolons:

```text
MODELOS_POOL_PEARL_WALLET=prl1youraddress
MODELOS_GPU_INDICES=0,1
MODELOS_LOG_LEVEL=Information
```

For a non-standard / private endpoint that uses TLS:

```text
MODELOS_POOL_TLS=1
```

`MODELOS_POOL_USE_TLS` is still accepted for older flight sheets, but `MODELOS_POOL_TLS`
is the current setting name.

## Requirements

- Modern package: NVIDIA GPU with compute capability sm_80 or newer and a driver
  exposing CUDA 12.8 or newer.
- Legacy CUDA 12.2 package: NVIDIA GPU with compute capability sm_70 or newer and a
  driver exposing CUDA 12.2 or newer.
- 8 GB or more VRAM per mining GPU.
- HiveOS image with `jq`, `bc`, `nvidia-smi`, and CUDA 12 runtime libraries.

## Dashboard Stats

The miner writes `/run/hive/modelos-miner-stats.json`. HiveOS reads it through
`h-stats.sh` and graphs total TMADs/sec as the miner hashrate, with accepted and
rejected share counts from the pool.

## Logs

- Launcher log: `/var/log/miner/modelos-miner/h-run.log`
- Config log: `/var/log/miner/modelos-miner/h-config.log`
- Miner output: HiveOS miner log view

## Driver Fix

If startup reports missing CUDA 12 libraries or an old driver:

```bash
nvidia-driver-update --list
nvidia-driver-update <latest_550+>
reboot
```

For V100, T4, and RTX 20-series rigs on older drivers, install the CUDA 12.2 package
instead of the modern package.
