#!/usr/bin/env bash
###############################################################################
# h-stats.sh — sourced by the HiveOS agent to report hashrate/temps/shares.
# Must set two variables:  $khs  (total hashrate, kH/s)  and  $stats (JSON).
#
# It reads the JSON produced by modelos-stats-writer.sh and translates it into
# the format the HiveOS dashboard expects.
###############################################################################
STATS_FILE="/run/hive/modelos-miner-stats.json"

khs=0
stats=""

if [[ ! -f "$STATS_FILE" ]]; then
    # miner not reporting yet — return zeros so HiveOS shows the rig as online
    stats='{"hs":[0],"hs_units":"hs","temp":[0],"fan":[0],"uptime":0,"ar":[0,0],"algo":"modelos"}'
    khs=0
    return 0 2>/dev/null || exit 0
fi

if command -v jq >/dev/null 2>&1; then
    # ---- jq path -----------------------------------------------------------
    hs=$(jq -c '[.gpus[].tmads_per_sec]' "$STATS_FILE" 2>/dev/null)
    temp=$(jq -c '[.gpus[].temp_c]' "$STATS_FILE" 2>/dev/null)
    fan=$(jq -c '[.gpus[].fan_pct]' "$STATS_FILE" 2>/dev/null)
    bus=$(jq -c '[.gpus[].pci_bus_id]' "$STATS_FILE" 2>/dev/null)
    total=$(jq -r '.total_tmads_per_sec // 0' "$STATS_FILE" 2>/dev/null)
    uptime=$(jq -r '.uptime_seconds // 0' "$STATS_FILE" 2>/dev/null)
    acc=$(jq -r '.shares.accepted // 0' "$STATS_FILE" 2>/dev/null)
    rej=$(jq -r '.shares.rejected // 0' "$STATS_FILE" 2>/dev/null)
    ver=$(jq -r '.version // "2.2.0"' "$STATS_FILE" 2>/dev/null)

    [[ -z "$hs"   || "$hs"   == "null" ]] && hs='[0]'
    [[ -z "$temp" || "$temp" == "null" ]] && temp='[0]'
    [[ -z "$fan"  || "$fan"  == "null" ]] && fan='[0]'
    [[ -z "$bus"  || "$bus"  == "null" ]] && bus='[0]'

    stats=$(jq -nc \
        --argjson hs "$hs" --argjson temp "$temp" --argjson fan "$fan" \
        --argjson bus "$bus" --argjson up "${uptime:-0}" \
        --argjson acc "${acc:-0}" --argjson rej "${rej:-0}" --arg ver "$ver" \
        '{hs:$hs, hs_units:"hs", temp:$temp, fan:$fan, uptime:$up,
          ar:[$acc,$rej], bus_numbers:$bus, algo:"modelos", ver:$ver}')

    # HiveOS khs is kH/s — express the TMADs total scaled to kilo-units
    khs=$(awk "BEGIN{printf \"%.3f\", ${total:-0}/1000}")
else
    # ---- python fallback ---------------------------------------------------
    read -r khs stats < <(python3 - "$STATS_FILE" <<'PY'
import json, sys
try:
    d = json.load(open(sys.argv[1]))
except Exception:
    print("0", '{"hs":[0],"hs_units":"hs","temp":[0],"fan":[0],"uptime":0,"ar":[0,0],"algo":"modelos"}')
    sys.exit()
g = d.get("gpus", [])
hs   = [x.get("tmads_per_sec", 0) for x in g] or [0]
temp = [x.get("temp_c", 0)        for x in g] or [0]
fan  = [x.get("fan_pct", 0)       for x in g] or [0]
bus  = [x.get("pci_bus_id", i)    for i, x in enumerate(g)] or [0]
sh   = d.get("shares", {})
out = {
  "hs": hs, "hs_units": "hs", "temp": temp, "fan": fan,
  "uptime": d.get("uptime_seconds", 0),
  "ar": [sh.get("accepted", 0), sh.get("rejected", 0)],
  "bus_numbers": bus, "algo": "modelos", "ver": d.get("version", "2.2.0"),
}
total = d.get("total_tmads_per_sec", sum(hs))
print("%.3f" % (total / 1000.0), json.dumps(out, separators=(",", ":")))
PY
)
fi
