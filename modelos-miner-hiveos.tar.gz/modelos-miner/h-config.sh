#!/usr/bin/env bash
###############################################################################
# h-config.sh — turns the Flight Sheet fields into miner env vars.
#
# HiveOS gives us these env vars from the Flight Sheet:
#   CUSTOM_TEMPLATE     "Wallet and worker template"  (e.g. %WAL%.%WORKER_NAME%)
#   CUSTOM_URL          "Pool URL"                     (e.g. stratum.modeloslab.xyz:5566)
#   CUSTOM_USER_CONFIG  "Custom miner config" (extra)  (e.g. MODELOS_POOL_PEARL_WALLET=prl1...)
#   CUSTOM_PASS         pool password (unused by modelOS, kept for completeness)
#
# This script is HARDENED against the bugs documented in the field report:
#   * %WAL% / %WORKER_NAME% not substituted by HiveOS  -> we substitute manually
#   * PRL wallet / extra config not exported to miner   -> we parse & export them
###############################################################################
cd "$(dirname "$0")" || exit 1

# Preserve the Flight-Sheet values BEFORE sourcing the manifest, then restore
# them — the per-rig Flight Sheet must always win over any manifest default.
_FS_TEMPLATE="$CUSTOM_TEMPLATE"
_FS_URL="$CUSTOM_URL"
_FS_USERCFG="$CUSTOM_USER_CONFIG"
[[ -f h-manifest.conf ]] && source h-manifest.conf
[[ -n "$_FS_TEMPLATE" ]] && CUSTOM_TEMPLATE="$_FS_TEMPLATE"
[[ -n "$_FS_URL" ]]      && CUSTOM_URL="$_FS_URL"
[[ -n "$_FS_USERCFG" ]]  && CUSTOM_USER_CONFIG="$_FS_USERCFG"

CONF="${CUSTOM_CONFIG_FILENAME:-/hive/miners/custom/modelos-miner/modelos.generated.conf}"

# ----------------------------------------------------------------------------
# 1. Resolve the worker name (env -> rig.conf -> hostname)
# ----------------------------------------------------------------------------
WORKER="$WORKER_NAME"
if [[ -z "$WORKER" && -f /hive-config/rig.conf ]]; then
    WORKER="$(. /hive-config/rig.conf 2>/dev/null; echo "${WORKER_NAME:-$RIG_NAME}")"
fi
[[ -z "$WORKER" ]] && WORKER="$(hostname)"

# ----------------------------------------------------------------------------
# 2. Resolve the wallet template, substituting placeholders ourselves so that a
#    broken HiveOS substitution can never produce "wallet=%WAL%".
# ----------------------------------------------------------------------------
TEMPLATE="${CUSTOM_TEMPLATE:-%WAL%.%WORKER_NAME%}"
TEMPLATE="${TEMPLATE//%WORKER_NAME%/$WORKER}"

# Split template into wallet + worker on the first dot
if [[ "$TEMPLATE" == *.* ]]; then
    MDL_WALLET="${TEMPLATE%%.*}"
    POOL_WORKER="${TEMPLATE#*.}"
else
    MDL_WALLET="$TEMPLATE"
    POOL_WORKER="$WORKER"
fi

# Optional inline PRL wallet carried INSIDE the Template using a '+' separator:
#     mdl1ADDR+prl1ADDR.%WORKER_NAME%
# This is the only reliable channel on HiveOS builds that pass neither %WAL%
# nor the "Custom miner config" field to custom miners. Bech32 addresses never
# contain '+' or '.', so the split is unambiguous.
TPL_PEARL=""
if [[ "$MDL_WALLET" == *+* ]]; then
    TPL_PEARL="${MDL_WALLET#*+}"
    MDL_WALLET="${MDL_WALLET%%+*}"
fi

# ----------------------------------------------------------------------------
# 3. Parse the "Custom miner config" extra field into KEY=VALUE exports.
#    Accepts lines like:
#        MODELOS_POOL_PEARL_WALLET=prl1...
#        MODELOS_POOL_WALLET=mdl1...        (optional MDL safety net)
#        MODELOS_POOL_TLS=1
#    Also tolerates docker-style "-e KEY=VALUE" tokens.
# ----------------------------------------------------------------------------
USER_EXPORTS=""
declare -A UC
if [[ -n "$CUSTOM_USER_CONFIG" ]]; then
    # normalise: turn "-e " into newlines, split spaces between KEY=VAL tokens
    NORM="$(echo "$CUSTOM_USER_CONFIG" | sed 's/-e /\n/g' | tr ' ' '\n')"
    while IFS= read -r line; do
        line="${line//$'\r'/}"
        [[ -z "$line" ]] && continue
        [[ "$line" != *=* ]] && continue
        key="${line%%=*}"; val="${line#*=}"
        key="$(echo "$key" | tr -cd 'A-Za-z0-9_')"
        [[ -z "$key" ]] && continue
        UC["$key"]="$val"
    done <<< "$NORM"
fi

# MDL safety net: if HiveOS never substituted %WAL%, fall back to the extra field
if [[ "$MDL_WALLET" == "%WAL%" || -z "$MDL_WALLET" ]]; then
    if [[ -n "${UC[MODELOS_POOL_WALLET]}" ]]; then
        MDL_WALLET="${UC[MODELOS_POOL_WALLET]}"
    fi
fi

# PRL wallet precedence: Custom-miner-config field (if HiveOS passed it) wins,
# otherwise the inline '+' value from the Template.
PEARL_WALLET="${UC[MODELOS_POOL_PEARL_WALLET]:-$TPL_PEARL}"

# ----------------------------------------------------------------------------
# 4. Pool host / port from CUSTOM_URL
# ----------------------------------------------------------------------------
URL="${CUSTOM_URL:-stratum.modeloslab.xyz:5566}"
URL="${URL#*://}"          # strip stratum+tcp:// etc.
URL="${URL%/}"
POOL_HOST="${URL%%:*}"
POOL_PORT="${URL##*:}"
[[ "$POOL_PORT" == "$URL" ]] && POOL_PORT=5566

# ----------------------------------------------------------------------------
# 4b. SELF-PROTECTION: never clobber a good config with a bad default.
#     HiveOS may invoke h-config a second time at *run* time without the Flight
#     Sheet variables, which would yield MDL_WALLET="%WAL%". If we already have a
#     config carrying a real mdl1... wallet, keep it and exit instead of wiping it.
# ----------------------------------------------------------------------------
if [[ "$MDL_WALLET" != mdl1* ]]; then
    if [[ -f "$CONF" ]] && grep -q 'MODELOS_POOL_WALLET="mdl1' "$CONF"; then
        echo "[h-config] no valid wallet in environment — preserving existing config:"
        grep -E 'MODELOS_POOL_(WALLET|PEARL_WALLET)=' "$CONF" | sed 's/^/[h-config]   /'
        exit 0
    fi
fi

# ----------------------------------------------------------------------------
# 5. Emit the generated config (sourced by h-run.sh and h-stats.sh)
# ----------------------------------------------------------------------------
mkdir -p "$(dirname "$CONF")"
{
    echo "# Auto-generated by h-config.sh — do not edit by hand."
    echo "export MODELOS_POOL_WALLET=\"$MDL_WALLET\""
    echo "export MODELOS_POOL_WORKER=\"$POOL_WORKER\""
    echo "export MODELOS_POOL_HOST=\"$POOL_HOST\""
    echo "export MODELOS_POOL_PORT=\"$POOL_PORT\""
    echo "export MODELOS_POOL_TLS=\"${UC[MODELOS_POOL_TLS]:-0}\""
    echo "export MODELOS_HIVEOS_STATS_PATH=\"/run/hive/modelos-miner-stats.json\""
    [[ -n "$PEARL_WALLET" ]] && printf 'export MODELOS_POOL_PEARL_WALLET=%q\n' "$PEARL_WALLET"
    # export everything else the user put in the extra field (model, token...)
    for k in "${!UC[@]}"; do
        # these are handled explicitly above
        [[ "$k" == "MODELOS_POOL_WALLET" || "$k" == "MODELOS_POOL_PEARL_WALLET" ]] && continue
        printf 'export %s=%q\n' "$k" "${UC[$k]}"
    done
} > "$CONF"

echo "[h-config] MDL wallet : $MDL_WALLET"
echo "[h-config] worker     : $POOL_WORKER"
echo "[h-config] pool       : $POOL_HOST:$POOL_PORT"
[[ -n "$PEARL_WALLET" ]] && echo "[h-config] PRL wallet : $PEARL_WALLET"

# Sanity warning (does not abort — lets the user see it in the log)
if [[ "$MDL_WALLET" != mdl1* ]]; then
    echo "[h-config] WARNING: MDL wallet does not look like an mdl1... address."
    echo "[h-config]          Put your full address in the Template as 'mdl1youraddr.%WORKER_NAME%'"
    echo "[h-config]          or add 'MODELOS_POOL_WALLET=mdl1youraddr' to the Custom miner config field."
fi
