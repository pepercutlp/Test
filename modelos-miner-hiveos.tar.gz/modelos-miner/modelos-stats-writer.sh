#!/usr/bin/env bash
###############################################################################
# modelos-stats-writer.sh — background helper that produces the stats JSON the
# HiveOS dashboard reads (the miner doesn't reliably create it when launched
# through the glibc loader). Runs forever, refreshing every 10 s.
#
# Output: /run/hive/modelos-miner-stats.json
###############################################################################
export LC_ALL=C
STATS_FILE="/run/hive/modelos-miner-stats.json"
LOG_FILE="/var/log/miner/modelos-miner/modelos-miner.log"
mkdir -p /run/hive

while true; do
    PID=$(pgrep -f 'modelos-miner mine-blocks' | head -1)
    if [[ -z "$PID" ]]; then
        sleep 5
        continue
    fi

    # Last chunk of the miner's screen log (prefer direct file read over `miner log`)
    if [[ -f "$LOG_FILE" ]]; then
        LOG=$(tail -200 "$LOG_FILE" 2>/dev/null)
    else
        LOG=$(timeout 5 bash -c 'miner log 2>/dev/null' | tail -200)
    fi

    GPU_COUNT=$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | wc -l)
    [[ -z "$GPU_COUNT" || "$GPU_COUNT" -lt 1 ]] && GPU_COUNT=1

    # Per-GPU hashrate from "worker[i] [stats] ... tmads/s=NN.N"
    HS_ARRAY=(); TOTAL=0
    for ((i=0; i<GPU_COUNT; i++)); do
        VAL=$(echo "$LOG" | grep "worker\[$i\] \[stats\]" | tail -1 | grep -oP 'tmads/s=\K[0-9.]+')
        INT=$(printf "%.0f" "${VAL:-0}" 2>/dev/null || echo 0)
        HS_ARRAY+=("$INT")
        TOTAL=$((TOTAL + INT))
    done

    mapfile -t TEMPS < <(nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader,nounits 2>/dev/null)
    mapfile -t FANS  < <(nvidia-smi --query-gpu=fan.speed --format=csv,noheader,nounits 2>/dev/null | sed 's/[^0-9]//g')

    if [[ -f "$LOG_FILE" ]]; then
        ACCEPTED=$(grep -c "accepted=True" "$LOG_FILE" 2>/dev/null)
        REJECTED=$(grep -c "accepted=False" "$LOG_FILE" 2>/dev/null)
    else
        ACCEPTED=$(echo "$LOG" | grep -c "accepted=True")
        REJECTED=$(echo "$LOG" | grep -c "accepted=False")
    fi

    UPTIME=$(ps -o etimes= -p "$PID" 2>/dev/null | tr -d ' ')
    [[ -z "$UPTIME" ]] && UPTIME=0

    GPUS_JSON="["
    for ((i=0; i<GPU_COUNT; i++)); do
        [[ $i -gt 0 ]] && GPUS_JSON+=","
        T="${TEMPS[$i]:-0}"; F="${FANS[$i]:-0}"
        [[ ! "$T" =~ ^[0-9]+$ ]] && T=0
        [[ ! "$F" =~ ^[0-9]+$ ]] && F=0
        GPUS_JSON+="{\"tmads_per_sec\":${HS_ARRAY[$i]:-0},\"temp_c\":$T,\"fan_pct\":$F,\"pci_bus_id\":$i}"
    done
    GPUS_JSON+="]"

    printf '{"gpus":%s,"total_tmads_per_sec":%d,"uptime_seconds":%d,"version":"2.2.0","shares":{"accepted":%d,"rejected":%d}}\n' \
        "$GPUS_JSON" "$TOTAL" "${UPTIME:-0}" "${ACCEPTED:-0}" "${REJECTED:-0}" > "$STATS_FILE"

    sleep 10
done
