#!/usr/bin/env bash
###############################################################################
# modelos-deps.sh — ensure a glibc 2.38 + libstdc++ 13.2 loader is available.
#
# MUST be SOURCED (not executed). It sets two variables for the caller:
#   MODELOS_LOADER   -> path to ld-linux-x86-64.so.2  (empty if not needed)
#   MODELOS_LIBPATH  -> colon-joined lib dirs for --library-path (empty if N/A)
#
# Background (from the field report): the modelos-miner libs require GLIBC_2.38
# and GLIBCXX_3.4.32, but HiveOS (Ubuntu 22.04) ships glibc 2.35 + GCC 11.
# We install the newer libs side-by-side in /opt/glibc-2.38 — the system is
# never modified, so nothing else on the rig can break.
###############################################################################
MODELOS_LOADER=""
MODELOS_LIBPATH=""

GLIBC_DIR="${MODELOS_GLIBC_DIR:-/opt/glibc-2.38}"
LDSO="$GLIBC_DIR/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2"
LIBSTDCPP="$GLIBC_DIR/usr/lib/x86_64-linux-gnu/libstdc++.so.6"

# Package URLs (the only mirror that still serves these versions)
URL_GLIBC="${MODELOS_URL_GLIBC:-http://old-releases.ubuntu.com/ubuntu/pool/main/g/glibc/libc6_2.38-1ubuntu6_amd64.deb}"
URL_STDCPP="${MODELOS_URL_STDCPP:-http://old-releases.ubuntu.com/ubuntu/pool/main/g/gcc-13/libstdc++6_13.2.0-4ubuntu3_amd64.deb}"

# ---------------------------------------------------------------------------
# Decide whether the loader is even needed.
# If the system glibc already provides >= 2.38, skip everything.
# ---------------------------------------------------------------------------
_sys_glibc="$(ldd --version 2>/dev/null | head -1 | grep -oE '[0-9]+\.[0-9]+' | head -1)"
if [[ -n "$_sys_glibc" ]]; then
    if awk "BEGIN{exit !($_sys_glibc >= 2.38)}"; then
        echo "[deps] system glibc $_sys_glibc is new enough — no loader needed."
        return 0 2>/dev/null || exit 0
    fi
fi

# ---------------------------------------------------------------------------
# Install side-by-side libs if missing.
# ---------------------------------------------------------------------------
_fetch() { # url dest
    wget -q --show-progress -O "$2" "$1" || { echo "[deps] download failed: $1"; return 1; }
}

if [[ ! -f "$LDSO" ]]; then
    echo "[deps] installing glibc 2.38 into $GLIBC_DIR ..."
    mkdir -p "$GLIBC_DIR"
    tmp="$(mktemp -d)"
    if _fetch "$URL_GLIBC" "$tmp/libc6.deb"; then
        dpkg-deb -x "$tmp/libc6.deb" "$GLIBC_DIR" && echo "[deps] glibc 2.38 OK"
    fi
    rm -rf "$tmp"
fi

if [[ ! -f "$LIBSTDCPP" ]]; then
    echo "[deps] installing libstdc++ 13.2 into $GLIBC_DIR ..."
    tmp="$(mktemp -d)"
    if _fetch "$URL_STDCPP" "$tmp/libstdcpp.deb"; then
        dpkg-deb -x "$tmp/libstdcpp.deb" "$GLIBC_DIR" && echo "[deps] libstdc++ 13.2 OK"
    fi
    rm -rf "$tmp"
fi

# ---------------------------------------------------------------------------
# Export results if the loader is now in place.
# ---------------------------------------------------------------------------
if [[ -f "$LDSO" ]]; then
    MODELOS_LOADER="$LDSO"
    MODELOS_LIBPATH="$GLIBC_DIR/lib/x86_64-linux-gnu:$GLIBC_DIR/usr/lib/x86_64-linux-gnu"
    echo "[deps] using loader: $MODELOS_LOADER"
else
    echo "[deps] WARNING: glibc 2.38 loader unavailable — will try system loader."
fi
