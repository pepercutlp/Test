# modelos-miner — HiveOS custom miner (self-bootstrapping)

A drop-in HiveOS **Custom** miner for the modelOS pool that mines **MDL** (and
optionally **PRL** via AuxPoW). It wraps the official `modelos-miner` and applies
— automatically, on every rig — all of the fixes discovered during the first
manual deployment, so any operator can run it just by filling in their own wallet
on the Flight Sheet.

## What it fixes for you (no manual steps)

| # | Problem on a fresh rig | How this package handles it |
|---|------------------------|-----------------------------|
| 1 | Install dir not created / `h-manifest.conf` missing | Standard tar layout (`modelos-miner/...`); install fallback in INSTALL guide |
| 2 | `Driver compatibility check failed (exitcode=5)` on new NVIDIA drivers | Binary is launched directly; the broken `check-driver.sh` is never called |
| 3 | `GLIBC_2.38 not found` | `modelos-deps.sh` installs glibc 2.38 side-by-side in `/opt/glibc-2.38` (only if the system glibc is older) |
| 4 | `GLIBCXX_3.4.32 not found` | Same helper installs libstdc++ 13.2 next to it |
| 5 | `Invalid MDL address` / `wallet=%WAL%` not substituted | `h-config.sh` substitutes `%WAL%`/`%WORKER_NAME%` itself, with fallbacks |
| 6 | `MODELOS_POOL_PEARL_WALLET` (extra config) not exported | `h-config.sh` parses the extra-config field and exports every key |
| 7 | Hashrate shows `n/a` in dashboard | `modelos-stats-writer.sh` writes the stats JSON the dashboard reads |

Nothing is hardcoded — every rig/operator uses their own wallet from the Flight
Sheet. The proprietary miner binary is **not** bundled; it is downloaded from the
official release URL on first run (with SHA-256 verification when published).

## Files

```
modelos-miner/
├── h-manifest.conf            # HiveOS manifest (name/version/paths)
├── h-config.sh                # Flight-Sheet fields -> miner env (hardened parsing)
├── h-run.sh                   # entry point: bootstrap -> deps -> stats -> launch
├── h-stats.sh                 # reports hashrate/temps/shares to HiveOS
├── modelos-bootstrap.sh       # downloads the official miner payload (once)
├── modelos-deps.sh            # installs glibc 2.38 + libstdc++ 13.2 if needed
├── modelos-stats-writer.sh    # background stats producer
└── h-readme.md                # this file
```

## Install

Create a **Custom** Flight Sheet in HiveOS with:

- **Installation URL** — the URL where YOU host this package's tarball
  (e.g. a GitHub Release of `modelos-miner-hiveos.tar.gz`).
- **Hash algorithm** — `modelos`
- **Pool URL** — `stratum.modeloslab.xyz:5566`
- **Wallet and worker template** — `%WAL%.%WORKER_NAME%`
  *(if your HiveOS doesn't substitute `%WAL%`, put your full address here instead:
  `mdl1youraddress.%WORKER_NAME%`)*
- **Wallet** — your `mdl1...` address
- **Custom miner config** — to also mine PRL:
  `MODELOS_POOL_PEARL_WALLET=prl1youraddress`
  *(optional safety net: also add `MODELOS_POOL_WALLET=mdl1youraddress`)*

Apply the Flight Sheet. First start downloads the miner + libs (1–2 min), then
mining begins. Check earnings at `pool.modeloslab.xyz/lookup`.

### If the installer can't create the directory (Problem 1)

Run once over SSH, then re-apply the Flight Sheet:

```bash
mkdir -p /hive/miners/custom/modelos-miner
cd /hive/miners/custom/modelos-miner
wget <YOUR_PACKAGE_URL> -O pkg.tar.gz
tar -xzf pkg.tar.gz --strip-components=1
rm pkg.tar.gz
chmod +x h-*.sh modelos-*.sh
```

## Configurable overrides (env, optional)

| Variable | Default | Purpose |
|----------|---------|---------|
| `MODELOS_OFFICIAL_URL` | official latest tarball | where to fetch the miner |
| `MODELOS_GLIBC_DIR` | `/opt/glibc-2.38` | side-by-side libs location |
| `MODELOS_URL_GLIBC` / `MODELOS_URL_STDCPP` | old-releases URLs | override mirrors |

## Survives miner updates

`/opt/glibc-2.38` persists across reinstalls. The stats writer is (re)started by
`h-run.sh` on every launch, so a reboot needs no manual steps. Because this is a
wrapper, a new official miner release is picked up automatically the next time
`miner/modelos-miner` is absent (delete it to force a refresh).
