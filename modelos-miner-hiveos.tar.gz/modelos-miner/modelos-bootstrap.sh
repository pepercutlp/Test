#!/usr/bin/env bash
###############################################################################
# modelos-bootstrap.sh — fetch the OFFICIAL modelos-miner payload and drop it
# next to our wrapper scripts WITHOUT overwriting them.
#
# The official tarball ships its own h-run.sh / h-config.sh / h-manifest.conf.
# We only copy its `miner/` payload (binary + libs) and `scripts/` so our
# hardened wrapper stays in control.
###############################################################################
set -u
cd "$(dirname "$0")" || exit 1
MINER_ROOT="$(pwd)"

OFFICIAL_URL="${MODELOS_OFFICIAL_URL:-https://pool.modeloslab.xyz/releases/modelos-miner-latest.tar.gz}"

if [[ -x "$MINER_ROOT/miner/modelos-miner" ]]; then
    echo "[bootstrap] miner already present — nothing to do."
    exit 0
fi

command -v wget >/dev/null 2>&1 || { echo "[bootstrap] wget missing"; exit 1; }

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

echo "[bootstrap] downloading official miner: $OFFICIAL_URL"
if ! wget -q --show-progress -O "$TMP/m.tar.gz" "$OFFICIAL_URL"; then
    echo "[bootstrap] download failed"; exit 1
fi

# Optional checksum verification (published next to the tarball)
if wget -q -O "$TMP/m.sha256" "${OFFICIAL_URL}.sha256" 2>/dev/null && [[ -s "$TMP/m.sha256" ]]; then
    EXPECT="$(awk '{print $1}' "$TMP/m.sha256")"
    ACTUAL="$(sha256sum "$TMP/m.tar.gz" | awk '{print $1}')"
    if [[ -n "$EXPECT" && "$EXPECT" != "$ACTUAL" ]]; then
        echo "[bootstrap] CHECKSUM MISMATCH! expected=$EXPECT got=$ACTUAL"
        exit 1
    fi
    echo "[bootstrap] checksum OK"
fi

echo "[bootstrap] extracting..."
mkdir -p "$TMP/x"
tar -xzf "$TMP/m.tar.gz" -C "$TMP/x" --strip-components=1 || {
    echo "[bootstrap] extract failed"; exit 1; }

# Copy ONLY the payload — never the official h-*.sh / h-manifest.conf
if [[ -d "$TMP/x/miner" ]]; then
    cp -a "$TMP/x/miner" "$MINER_ROOT/"
else
    echo "[bootstrap] unexpected archive layout (no miner/ dir)"; exit 1
fi
[[ -d "$TMP/x/scripts" ]] && cp -a "$TMP/x/scripts" "$MINER_ROOT/"

chmod +x "$MINER_ROOT/miner/modelos-miner" 2>/dev/null

# Create the bare-soname symlink the .NET host dlopen's at runtime
# (libpearl_gemm_capi.so -> the kernel matching this GPU's compute capability).
# Done here so it always exists right after a (re)install; h-run re-checks too.
LIBDIR="$MINER_ROOT/miner/lib"
if [[ -d "$LIBDIR" ]]; then
    CAP="$(nvidia-smi --query-gpu=compute_cap --format=csv,noheader 2>/dev/null | head -1 | tr -d ' ')"
    case "$CAP" in
        8.0|8.6|8.7) ARCH=ampere ;;
        8.9)         ARCH=ada ;;
        9.0)         ARCH=h100 ;;
        10.0)        ARCH=b200 ;;
        12.0)        ARCH=blackwell ;;
        *)           ARCH=portable ;;
    esac
    [[ -f "$LIBDIR/libpearl_gemm_capi_${ARCH}.so" ]] || ARCH=portable
    if [[ -f "$LIBDIR/libpearl_gemm_capi_${ARCH}.so" ]]; then
        ln -sf "libpearl_gemm_capi_${ARCH}.so" "$LIBDIR/libpearl_gemm_capi.so"
        echo "[bootstrap] kernel symlink -> libpearl_gemm_capi_${ARCH}.so (compute_cap=${CAP:-unknown})"
    fi
fi

if [[ -x "$MINER_ROOT/miner/modelos-miner" ]]; then
    echo "[bootstrap] done — $("$MINER_ROOT/miner/modelos-miner" version 2>/dev/null | head -1)"
    exit 0
fi
echo "[bootstrap] FATAL: miner binary still missing after extract"
exit 1
