#!/usr/bin/env bash
###############################################################################
# h-run.sh — entry point launched by the HiveOS agent.
#
# Order of operations (each step is idempotent and self-healing):
#   1. source manifest + generated config
#   2. ensure the official modelos-miner binary is present (download if missing)
#   3. ensure a compatible glibc 2.38 / libstdc++ 13.2 loader (download if needed)
#   4. start the stats writer in the background
#   5. exec the miner (through the loader when the system glibc is too old)
#
# All fixes from the field report are applied automatically here, so the same
# package works on any rig regardless of NVIDIA driver / glibc version.
###############################################################################
cd "$(dirname "$0")" || exit 1
MINER_ROOT="$(pwd)"

source h-manifest.conf 2>/dev/null

# (re)generate the runtime config in case the agent skipped h-config.sh
[[ -x ./h-config.sh ]] && ./h-config.sh >/dev/null 2>&1
CONF="${CUSTOM_CONFIG_FILENAME:-$MINER_ROOT/modelos.generated.conf}"
[[ -f "$CONF" ]] && source "$CONF"

# ---------------------------------------------------------------------------
# 1. Make sure the official miner payload is present
# ---------------------------------------------------------------------------
if [[ ! -x "$MINER_ROOT/miner/modelos-miner" ]]; then
    echo "[h-run] official miner not found — bootstrapping..."
    if ! ./modelos-bootstrap.sh; then
        echo "[h-run] FATAL: could not download/extract the official miner."
        exit 1
    fi
fi

# ---------------------------------------------------------------------------
# 2. Make sure we have a compatible loader (glibc 2.38 + libstdc++ 13.2).
#    modelos-deps.sh exports MODELOS_LOADER and MODELOS_LIBPATH (empty when the
#    system glibc is already new enough).
# ---------------------------------------------------------------------------
MODELOS_LOADER=""
MODELOS_LIBPATH=""
if [[ -f ./modelos-deps.sh ]]; then
    source ./modelos-deps.sh
fi

# ---------------------------------------------------------------------------
# 3. Driver / CUDA check is intentionally NOT run.
#    The official scripts/check-driver.sh mis-parses newer nvidia-smi output
#    ("CUDA UMD Version: …") and aborts with exitcode 5. We launch the binary
#    directly, so that check is bypassed by design. The miner does its own
#    runtime capability detection.
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# 3b. Select the GPU-specific GEMM kernel.
#     The package ships per-architecture kernels (libpearl_gemm_capi_<arch>.so)
#     but the .NET host dlopen's the bare name "libpearl_gemm_capi.so". The
#     official installer picks the right one; since we bypass it, we create the
#     symlink ourselves based on the GPU compute capability. Falls back to the
#     "portable" kernel when the arch is unknown or its kernel isn't shipped.
# ---------------------------------------------------------------------------
LIBDIR="$MINER_ROOT/miner/lib"
if [[ -d "$LIBDIR" ]]; then
    CAP="$(nvidia-smi --query-gpu=compute_cap --format=csv,noheader 2>/dev/null | head -1 | tr -d ' ')"
    case "$CAP" in
        8.0|8.6|8.7) ARCH=ampere ;;
        8.9)         ARCH=ada ;;
        9.0)         ARCH=h100 ;;
        10.0)        ARCH=b200 ;;
        12.0)        ARCH=blackwell ;;
        *)           ARCH=portable ;;
    esac
    [[ -f "$LIBDIR/libpearl_gemm_capi_${ARCH}.so" ]] || ARCH=portable
    if [[ -f "$LIBDIR/libpearl_gemm_capi_${ARCH}.so" ]]; then
        ln -sf "libpearl_gemm_capi_${ARCH}.so" "$LIBDIR/libpearl_gemm_capi.so"
        echo "[h-run] GPU compute_cap=${CAP:-unknown} -> kernel libpearl_gemm_capi_${ARCH}.so"
    else
        echo "[h-run] WARNING: no libpearl_gemm_capi_*.so kernel found in $LIBDIR"
    fi
fi

# ---------------------------------------------------------------------------
# 4. Start the HiveOS stats writer (single instance)
# ---------------------------------------------------------------------------
if [[ -x ./modelos-stats-writer.sh ]]; then
    if ! pgrep -f modelos-stats-writer.sh >/dev/null 2>&1; then
        nohup ./modelos-stats-writer.sh >/var/log/modelos-stats-writer.log 2>&1 &
        echo "[h-run] stats writer started (pid $!)"
    fi
fi

# ---------------------------------------------------------------------------
# 5. Launch the miner (foreground / exec so HiveOS manages the process)
# ---------------------------------------------------------------------------
echo "[h-run] starting modelos-miner: wallet=$MODELOS_POOL_WALLET worker=$MODELOS_POOL_WORKER pool=$MODELOS_POOL_HOST:$MODELOS_POOL_PORT"
[[ -n "$MODELOS_POOL_PEARL_WALLET" ]] && echo "[h-run] PRL (AuxPoW) wallet: $MODELOS_POOL_PEARL_WALLET"

cd "$MINER_ROOT"

# CRITICAL: the miner's own native libs (libpearl_gemm_capi.so, etc.) live in
# miner/lib and are dlopen'd BY SONAME at runtime by the .NET host. That lookup
# uses the LD_LIBRARY_PATH *environment variable* — passing the dir only via the
# loader's --library-path is NOT enough. So we export it here. We deliberately
# keep ONLY miner/lib in the env (not the glibc-2.38 dirs) so child processes
# launched with the system loader don't pick up the newer libc.
export LD_LIBRARY_PATH="$MINER_ROOT/miner/lib:$MINER_ROOT/miner/lib/cuda${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"

if [[ -n "$MODELOS_LOADER" ]]; then
    echo "[h-run] launching via glibc-2.38 loader (LD_LIBRARY_PATH=$LD_LIBRARY_PATH)"
    # --library-path additionally supplies glibc 2.38 + libstdc++ 13.2 so the
    # loader can resolve the native libs' GLIBC_2.38 / GLIBCXX_3.4.32 symbols.
    exec "$MODELOS_LOADER" \
        --library-path "$MODELOS_LIBPATH:$MINER_ROOT/miner/lib:$MINER_ROOT/miner/lib/cuda:$LD_LIBRARY_PATH" \
        ./miner/modelos-miner mine-blocks 2>&1
else
    echo "[h-run] launching with system loader (glibc is new enough)"
    exec ./miner/modelos-miner mine-blocks 2>&1
fi
