#!/usr/bin/env bash
###############################################################################
# h-run.sh — entry point launched by the HiveOS agent.
#
# Order of operations (each step is idempotent and self-healing):
#   1. source manifest + generated config
#   2. ensure the official modelos-miner binary is present (download if missing)
#   3. ensure a compatible glibc 2.38 / libstdc++ 13.2 loader (download if needed)
#   4. start the stats writer in the background
#   5. exec the miner (through the loader when the system glibc is too old)
#
# All fixes from the field report are applied automatically here, so the same
# package works on any rig regardless of NVIDIA driver / glibc version.
###############################################################################
cd "$(dirname "$0")" || exit 1
MINER_ROOT="$(pwd)"

source h-manifest.conf 2>/dev/null

# (re)generate the runtime config in case the agent skipped h-config.sh
[[ -x ./h-config.sh ]] && ./h-config.sh >/dev/null 2>&1
CONF="${CUSTOM_CONFIG_FILENAME:-$MINER_ROOT/modelos.generated.conf}"
[[ -f "$CONF" ]] && source "$CONF"

# ---------------------------------------------------------------------------
# 1. Make sure the official miner payload is present
# ---------------------------------------------------------------------------
if [[ ! -x "$MINER_ROOT/miner/modelos-miner" ]]; then
    echo "[h-run] official miner not found — bootstrapping..."
    if ! ./modelos-bootstrap.sh; then
        echo "[h-run] FATAL: could not download/extract the official miner."
        exit 1
    fi
fi

# ---------------------------------------------------------------------------
# 2. Make sure we have a compatible loader (glibc 2.38 + libstdc++ 13.2).
#    modelos-deps.sh exports MODELOS_LOADER and MODELOS_LIBPATH (empty when the
#    system glibc is already new enough).
# ---------------------------------------------------------------------------
MODELOS_LOADER=""
MODELOS_LIBPATH=""
if [[ -f ./modelos-deps.sh ]]; then
    source ./modelos-deps.sh
fi

# ---------------------------------------------------------------------------
# 3. Driver / CUDA check is intentionally NOT run.
#    The official scripts/check-driver.sh mis-parses newer nvidia-smi output
#    ("CUDA UMD Version: …") and aborts with exitcode 5. We launch the binary
#    directly, so that check is bypassed by design. The miner does its own
#    runtime capability detection.
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# 4. Start the HiveOS stats writer (single instance)
# ---------------------------------------------------------------------------
if [[ -x ./modelos-stats-writer.sh ]]; then
    if ! pgrep -f modelos-stats-writer.sh >/dev/null 2>&1; then
        nohup ./modelos-stats-writer.sh >/var/log/modelos-stats-writer.log 2>&1 &
        echo "[h-run] stats writer started (pid $!)"
    fi
fi

# ---------------------------------------------------------------------------
# 5. Launch the miner (foreground / exec so HiveOS manages the process)
# ---------------------------------------------------------------------------
echo "[h-run] starting modelos-miner: wallet=$MODELOS_POOL_WALLET worker=$MODELOS_POOL_WORKER pool=$MODELOS_POOL_HOST:$MODELOS_POOL_PORT"
[[ -n "$MODELOS_POOL_PEARL_WALLET" ]] && echo "[h-run] PRL (AuxPoW) wallet: $MODELOS_POOL_PEARL_WALLET"

cd "$MINER_ROOT"
if [[ -n "$MODELOS_LOADER" ]]; then
    echo "[h-run] launching via glibc-2.38 loader"
    exec "$MODELOS_LOADER" \
        --library-path "$MODELOS_LIBPATH:$MINER_ROOT/miner/lib:$LD_LIBRARY_PATH" \
        ./miner/modelos-miner mine-blocks 2>&1
else
    echo "[h-run] launching with system loader (glibc is new enough)"
    export LD_LIBRARY_PATH="$MINER_ROOT/miner/lib:$LD_LIBRARY_PATH"
    exec ./miner/modelos-miner mine-blocks 2>&1
fi
