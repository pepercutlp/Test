#!/usr/bin/env bash
# Sourced from /hive/miners/custom/h-stats.sh (cwd=/hive/miners/custom).

SCRIPT_DIR="${MINER_DIR}/${CUSTOM_MINER}"
[[ -f "${SCRIPT_DIR}/h-manifest.conf" ]] && source "${SCRIPT_DIR}/h-manifest.conf"

LOG_GLOB="${CUSTOM_LOG_BASENAME}-gpu*.log"
VER="${CUSTOM_VERSION:-unknown}"

GPU_FILE="${GPU_STATS_JSON:-}"
[[ -z "${GPU_FILE}" && -f /run/hive/gpu_stats.json ]] && GPU_FILE=/run/hive/gpu_stats.json

if [[ -n "${GPU_FILE}" && -f "${GPU_FILE}" ]]; then
	GS="$(<"${GPU_FILE}")"
else
	GS="{}"
fi
GS="$(echo "${GS}" | jq -c . 2>/dev/null || echo '{}')"

hs_values=()
total_mh="0"
for log_file in ${LOG_GLOB}; do
	[[ -f "${log_file}" ]] || continue
	line="$(grep '\[HASH\]' "${log_file}" 2>/dev/null | tail -n 1 || true)"
	[[ -z "${line}" ]] && continue
	mh="$(echo "${line}" | sed -n 's/.*| \([0-9.]*\) MH\/s.*/\1/p' | tail -n 1)"
	mh_safe="$(echo "${mh}" | tr -cd '0-9.' | head -c 32)"
	[[ -z "${mh_safe}" ]] && mh_safe="0"
	hs_values+=("${mh_safe}")
	if command -v bc >/dev/null 2>&1; then
		total_mh="$(echo "${total_mh} + ${mh_safe}" | bc)"
	else
		total_mh="$(awk -v a="${total_mh}" -v b="${mh_safe}" 'BEGIN { printf "%.3f", a + b }')"
	fi
done

if [[ "${#hs_values[@]}" -eq 0 ]]; then
	hs_values=("0")
fi

if command -v bc >/dev/null 2>&1; then
	khs="$(echo "scale=0; (${total_mh} * 1000) / 1" | bc)"
else
	khs="$(awk -v m="${total_mh}" 'BEGIN { printf "%.0f", m * 1000 }')"
fi
[[ -z "${khs}" ]] && khs="0"

hs_json="$(printf '%s\n' "${hs_values[@]}" | jq -s 'map(tonumber)' 2>/dev/null || echo '[0]')"

stats="$(
	jq -n \
		--arg ver "${VER}" \
		--arg algo "${CUSTOM_ALGO:-hash256}" \
		--argjson hs "${hs_json}" \
		--argjson gs "${GS}" \
		'{
			hs: $hs,
			hs_units: "mhs",
			temp: ($gs.temp // []),
			fan: ($gs.fan // []),
			uptime: 0,
			ver: $ver,
			algo: $algo,
			bus_numbers: ($gs.bus_numbers // [])
		}'
)"
