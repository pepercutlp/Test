#!/usr/bin/env bash
set -euo pipefail
set -o pipefail

cd "$(dirname "$0")"
MINER_ROOT="$(pwd)"
export LD_LIBRARY_PATH="${MINER_ROOT}/cuda:${LD_LIBRARY_PATH:-}"

# Hive passes log basename via h-manifest when miner-run sources it; keep a safe default.
: "${CUSTOM_LOG_BASENAME:=/var/log/miner/hash256-miner/hash256-miner}"
mkdir -p "$(dirname "${CUSTOM_LOG_BASENAME}")" 2>/dev/null || true

export PYTHONUNBUFFERED=1

# Secrets and tuning live in .env (written by h-config.sh).
if [[ -f "${MINER_ROOT}/.env" ]]; then
	set -a
	# shellcheck disable=SC1090
	source "${MINER_ROOT}/.env"
	set +a
fi

if ! python3 -c "import web3, eth_account" >/dev/null 2>&1; then
	echo "Installing Python dependencies (web3, eth-account)..."
	python3 -m pip install --no-cache-dir -q -r "${MINER_ROOT}/requirements.txt" ||
		python3 -m pip install --user --no-cache-dir -q -r "${MINER_ROOT}/requirements.txt"
fi

CPU_FLAG=()
if [[ "${HASH256_FORCE_CPU:-0}" == "1" ]]; then
	CPU_FLAG+=(--cpu)
elif [[ ! -f "${MINER_ROOT}/cuda/libhash256miner.so" ]]; then
	if command -v nvcc >/dev/null 2>&1; then
		echo "cuda/libhash256miner.so missing; compiling on rig (needs CUDA toolkit + nvcc)..."
		( cd "${MINER_ROOT}/cuda" && make -f Makefile.hive clean && make -f Makefile.hive -j"$(nproc 2>/dev/null || echo 2)" )
	else
		echo "ERROR: ${MINER_ROOT}/cuda/libhash256miner.so not found and nvcc is not available."
		echo "On a PC with CUDA, run: cd cuda && make -f Makefile.hive"
		echo "Then copy libhash256miner.so into the cuda/ folder of this miner package."
		sleep 15
		exit 1
	fi
fi

EXTRA=(--batch-size "${BATCH_SIZE:-134217728}" --threads "${THREADS:-256}" --gas-limit "${GAS_LIMIT:-300000}")
[[ -n "${GAS_PRICE:-}" && "${GAS_PRICE}" != "null" ]] && EXTRA+=(--gas-price "${GAS_PRICE}")
[[ -n "${CUDA_LIB:-}" && "${CUDA_LIB}" != "null" ]] && EXTRA+=(--cuda-lib "${CUDA_LIB}")

if [[ "${HASH256_FORCE_CPU:-0}" == "1" ]]; then
	python3 "${MINER_ROOT}/miner.py" "${CPU_FLAG[@]}" "${EXTRA[@]}" 2>&1 | tee -a "${CUSTOM_LOG_BASENAME}.log"
	exit "${PIPESTATUS[0]}"
fi

GPU_LIST_RAW="${HASH256_GPU_LIST:-}"
if [[ -z "${GPU_LIST_RAW}" ]]; then
	if command -v nvidia-smi >/dev/null 2>&1; then
		GPU_LIST_RAW="$(nvidia-smi --query-gpu=index --format=csv,noheader 2>/dev/null | tr '\n' ',' | sed 's/,$//')"
	fi
fi
[[ -z "${GPU_LIST_RAW}" ]] && GPU_LIST_RAW="0"

IFS=',' read -r -a GPU_IDS <<< "${GPU_LIST_RAW}"
if [[ "${#GPU_IDS[@]}" -eq 0 ]]; then
	echo "No GPUs found in HASH256_GPU_LIST=${GPU_LIST_RAW}"
	exit 1
fi

PIDS=()
cleanup() {
	for p in "${PIDS[@]:-}"; do
		kill "$p" 2>/dev/null || true
	done
}
trap cleanup INT TERM EXIT

echo "Launching HASH256 miner on GPUs: ${GPU_LIST_RAW}"
for gpu in "${GPU_IDS[@]}"; do
	gpu="$(echo "${gpu}" | tr -d '[:space:]')"
	[[ -z "${gpu}" ]] && continue
	log_file="${CUSTOM_LOG_BASENAME}-gpu${gpu}.log"
	CUDA_VISIBLE_DEVICES="${gpu}" python3 "${MINER_ROOT}/miner.py" "${EXTRA[@]}" 2>&1 | sed -u "s/^/[GPU ${gpu}] /" | tee -a "${log_file}" &
	PIDS+=("$!")
done

if [[ "${#PIDS[@]}" -eq 0 ]]; then
	echo "No valid GPU processes started"
	exit 1
fi

wait -n "${PIDS[@]}"
exit_code=$?
echo "One of GPU miner processes exited with code ${exit_code}, stopping the rest..."
cleanup
exit "${exit_code}"
