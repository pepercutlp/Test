#!/usr/bin/env bash
# Sourced from /hive/miners/custom/h-stats.sh (cwd=/hive/miners/custom).

SCRIPT_DIR="${MINER_DIR}/${CUSTOM_MINER}"
[[ -f "${SCRIPT_DIR}/h-manifest.conf" ]] && source "${SCRIPT_DIR}/h-manifest.conf"

LOG_GLOB="${CUSTOM_LOG_BASENAME}-gpu*.log"
VER="${CUSTOM_VERSION:-unknown}"

GPU_FILE="${GPU_STATS_JSON:-}"
[[ -z "${GPU_FILE}" && -f /run/hive/gpu_stats.json ]] && GPU_FILE=/run/hive/gpu_stats.json

if [[ -n "${GPU_FILE}" && -f "${GPU_FILE}" ]]; then
	GS="$(<"${GPU_FILE}")"
else
	GS="{}"
fi
GS="$(echo "${GS}" | jq -c . 2>/dev/null || echo '{}')"

hs_values=()
total_mh="0"
extract_mh_from_log() {
	local file="$1"
	[[ -f "${file}" ]] || return 1
	# miner.py prints hashrate lines with carriage return ("\r"), not always with "\n"
	# so normalize both separators before parsing.
	tr '\r' '\n' < "${file}" 2>/dev/null | sed -n 's/.*\[HASH\].*| \([0-9.]*\) MH\/s.*/\1/p' | tail -n 1
}

gpu_count="$(echo "${GS}" | jq -r '(.temp // []) | length' 2>/dev/null || echo 0)"
[[ -z "${gpu_count}" || "${gpu_count}" == "null" ]] && gpu_count=0
if [[ "${gpu_count}" =~ ^[0-9]+$ ]] && [[ "${gpu_count}" -gt 0 ]]; then
	for ((i=0; i<gpu_count; i++)); do
		hs_values+=("0")
	done
fi

for log_file in ${LOG_GLOB}; do
	[[ -f "${log_file}" ]] || continue
	mh="$(extract_mh_from_log "${log_file}" || true)"
	mh_safe="$(echo "${mh}" | tr -cd '0-9.' | head -c 32)"
	[[ -z "${mh_safe}" ]] && mh_safe="0"
	gpu_idx="$(echo "${log_file}" | sed -n 's/.*-gpu\([0-9]\+\)\.log$/\1/p')"
	if [[ "${gpu_idx}" =~ ^[0-9]+$ ]]; then
		while [[ "${#hs_values[@]}" -le "${gpu_idx}" ]]; do
			hs_values+=("0")
		done
		hs_values["${gpu_idx}"]="${mh_safe}"
	else
		hs_values+=("${mh_safe}")
	fi
	if command -v bc >/dev/null 2>&1; then
		total_mh="$(echo "${total_mh} + ${mh_safe}" | bc)"
	else
		total_mh="$(awk -v a="${total_mh}" -v b="${mh_safe}" 'BEGIN { printf "%.3f", a + b }')"
	fi
done

if [[ "${#hs_values[@]}" -eq 0 ]]; then
	main_log="${CUSTOM_LOG_BASENAME}.log"
	mh="$(extract_mh_from_log "${main_log}" || true)"
	mh_safe="$(echo "${mh}" | tr -cd '0-9.' | head -c 32)"
	[[ -z "${mh_safe}" ]] && mh_safe="0"
	hs_values=("${mh_safe}")
	total_mh="${mh_safe}"
fi

if command -v awk >/dev/null 2>&1; then
	total_mh="$(printf '%s\n' "${hs_values[@]}" | awk '{s+=$1} END {printf "%.3f", s+0}')"
fi

if command -v bc >/dev/null 2>&1; then
	khs="$(echo "scale=0; (${total_mh} * 1000) / 1" | bc)"
else
	khs="$(awk -v m="${total_mh}" 'BEGIN { printf "%.0f", m * 1000 }')"
fi
[[ -z "${khs}" ]] && khs="0"

hs_json="$(printf '%s\n' "${hs_values[@]}" | jq -s 'map(tonumber)' 2>/dev/null || echo '[0]')"

stats="$(
	jq -n \
		--arg ver "${VER}" \
		--arg algo "${CUSTOM_ALGO:-hash256}" \
		--argjson hs "${hs_json}" \
		--argjson gs "${GS}" \
		'{
			hs: $hs,
			hs_units: "mhs",
			temp: ($gs.temp // []),
			fan: ($gs.fan // []),
			uptime: 0,
			ver: $ver,
			algo: $algo,
			bus_numbers: ($gs.bus_numbers // [])
		}'
)"
