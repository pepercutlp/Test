#!/usr/bin/env bash
# Sourced from /hive/miners/custom/h-stats.sh (cwd=/hive/miners/custom).

SCRIPT_DIR="${MINER_DIR}/${CUSTOM_MINER}"
[[ -f "${SCRIPT_DIR}/h-manifest.conf" ]] && source "${SCRIPT_DIR}/h-manifest.conf"

LOG="${CUSTOM_LOG_BASENAME}.log"
VER="${CUSTOM_VERSION:-unknown}"

GPU_FILE="${GPU_STATS_JSON:-}"
[[ -z "${GPU_FILE}" && -f /run/hive/gpu_stats.json ]] && GPU_FILE=/run/hive/gpu_stats.json

if [[ -n "${GPU_FILE}" && -f "${GPU_FILE}" ]]; then
	GS="$(<"${GPU_FILE}")"
else
	GS="{}"
fi
GS="$(echo "${GS}" | jq -c . 2>/dev/null || echo '{}')"

mh="0"
if [[ -f "${LOG}" ]]; then
	line="$(grep '\[HASH\]' "${LOG}" 2>/dev/null | tail -n 1 || true)"
	if [[ -n "${line}" ]]; then
		mh="$(echo "${line}" | sed -n 's/.*| \([0-9.]*\) MH\/s.*/\1/p' | tail -n 1)"
	fi
fi

mh_safe="$(echo "${mh}" | tr -cd '0-9.' | head -c 32)"
[[ -z "${mh_safe}" ]] && mh_safe="0"

if command -v bc >/dev/null 2>&1; then
	khs="$(echo "scale=0; (${mh_safe} * 1000) / 1" | bc)"
else
	khs="$(awk -v m="${mh_safe}" 'BEGIN { printf "%.0f", m * 1000 }')"
fi
[[ -z "${khs}" ]] && khs="0"

stats="$(
	jq -n \
		--arg mh "${mh_safe}" \
		--arg ver "${VER}" \
		--arg algo "${CUSTOM_ALGO:-hash256}" \
		--argjson gs "${GS}" \
		'{
			hs: [($mh|tonumber)],
			hs_units: "mhs",
			temp: ($gs.temp // []),
			fan: ($gs.fan // []),
			uptime: 0,
			ver: $ver,
			algo: $algo,
			bus_numbers: ($gs.bus_numbers // [])
		}'
)"
